package redraw;

import basemod.ReflectionHacks;
import com.badlogic.gdx.graphics.Texture;
import com.evacipated.cardcrawl.modthespire.lib.SpirePatch;
import com.evacipated.cardcrawl.modthespire.lib.SpirePostfixPatch;
import com.evacipated.cardcrawl.modthespire.lib.SpireReturn;
import com.megacrit.cardcrawl.characters.AbstractPlayer;
import com.megacrit.cardcrawl.characters.Ironclad;
import com.megacrit.cardcrawl.characters.Watcher;
import com.megacrit.cardcrawl.core.AbstractCreature;
import com.megacrit.cardcrawl.monsters.AbstractMonster;
import com.megacrit.cardcrawl.monsters.exordium.FungiBeast;
import redraw.util.TextureLoader;


public class Master {
    public Master() {
    }

    @SpirePatch(
            clz = Watcher.class,
            method = SpirePatch.CONSTRUCTOR,
            paramtypez = {String.class}
    )
    public static class BossPatch {
        public BossPatch() {
        }
        public static Texture loadTexture(String texturePath) {
            Texture texture = new Texture(texturePath);
            texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
            return texture;
        }

        @SpirePostfixPatch
        public static SpireReturn<Void> Insert(Watcher Master, String playerName) {
            if (1==1) {
                ReflectionHacks.setPrivate(Master, AbstractCreature.class, "atlas", null);
                ReflectionHacks.setPrivate(Master, AbstractPlayer.class, "img", loadTexture("redraw/images/Master.png"));
                //ReflectionHacks.setPrivate(Mario, String.class, "img", loadTexture("redraw/images/MarioReal.png"));

                //cultist.state.setAnimation(0, "Idle", true);
            }

            return SpireReturn.Continue();
        }
    }
}
