package redraw.monsters;

import basemod.ReflectionHacks;
import com.badlogic.gdx.graphics.Texture;
import com.evacipated.cardcrawl.modthespire.lib.SpirePatch;
import com.evacipated.cardcrawl.modthespire.lib.SpirePostfixPatch;
import com.evacipated.cardcrawl.modthespire.lib.SpireReturn;
import com.megacrit.cardcrawl.core.AbstractCreature;
import com.megacrit.cardcrawl.monsters.AbstractMonster;
import com.megacrit.cardcrawl.monsters.exordium.FungiBeast;
import com.megacrit.cardcrawl.monsters.exordium.LouseDefensive;
import com.megacrit.cardcrawl.monsters.exordium.LouseNormal;
import redraw.util.TextureLoader;


public class LouseGreen {
    public LouseGreen() {
    }

    @SpirePatch(
            clz = LouseDefensive.class,
            method = SpirePatch.CONSTRUCTOR,
            paramtypez = {float.class, float.class}
    )
    public static class BossPatch {
        public BossPatch() {
        }
        public static Texture loadTexture(String texturePath) {
            Texture texture = new Texture(texturePath);
            texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
            return texture;
        }

        @SpirePostfixPatch
        public static SpireReturn<Void> Insert(LouseDefensive LouseGreen, float x, float y) {
            if (1==1) {
                ReflectionHacks.setPrivate(LouseGreen, AbstractCreature.class, "atlas", null);
                ReflectionHacks.setPrivate(LouseGreen, AbstractMonster.class, "img", loadTexture("redraw/images/Petuniasmol.png"));


                //cultist.state.setAnimation(0, "Idle", true);
            }

            return SpireReturn.Continue();
        }
    }
}
