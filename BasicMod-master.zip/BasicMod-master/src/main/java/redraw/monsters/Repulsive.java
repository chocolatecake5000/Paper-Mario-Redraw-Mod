package redraw.monsters;

import basemod.ReflectionHacks;
import com.badlogic.gdx.graphics.Texture;
import com.evacipated.cardcrawl.modthespire.lib.SpirePatch;
import com.evacipated.cardcrawl.modthespire.lib.SpirePostfixPatch;
import com.evacipated.cardcrawl.modthespire.lib.SpireReturn;
import com.megacrit.cardcrawl.core.AbstractCreature;
import com.megacrit.cardcrawl.monsters.AbstractMonster;
import com.megacrit.cardcrawl.monsters.beyond.Exploder;
import com.megacrit.cardcrawl.monsters.beyond.Repulsor;
import com.megacrit.cardcrawl.monsters.exordium.FungiBeast;
import redraw.util.TextureLoader;


public class Repulsive {
    public Repulsive() {
    }

    @SpirePatch(
            clz = Repulsor.class,
            method = SpirePatch.CONSTRUCTOR,
            paramtypez = {float.class, float.class}
    )
    public static class BossPatch {
        public BossPatch() {
        }
        public static Texture loadTexture(String texturePath) {
            Texture texture = new Texture(texturePath);
            texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
            return texture;
        }

        @SpirePostfixPatch
        public static SpireReturn<Void> Insert(Repulsor Repulsive, float x, float y) {
            if (1==1) {
                ReflectionHacks.setPrivate(Repulsive, AbstractCreature.class, "atlas", null);
                ReflectionHacks.setPrivate(Repulsive, AbstractMonster.class, "img", loadTexture("redraw/images/BulletBill.png"));


                //cultist.state.setAnimation(0, "Idle", true);
            }

            return SpireReturn.Continue();
        }
    }
}
