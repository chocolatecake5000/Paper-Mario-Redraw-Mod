package redraw.monsters;

import basemod.ReflectionHacks;
import com.badlogic.gdx.graphics.Texture;
import com.evacipated.cardcrawl.modthespire.lib.SpirePatch;
import com.evacipated.cardcrawl.modthespire.lib.SpirePostfixPatch;
import com.evacipated.cardcrawl.modthespire.lib.SpireReturn;
import com.megacrit.cardcrawl.core.AbstractCreature;
import com.megacrit.cardcrawl.monsters.AbstractMonster;
import com.megacrit.cardcrawl.monsters.city.Snecko;
import com.megacrit.cardcrawl.monsters.exordium.*;
import redraw.util.TextureLoader;


public class CoolGhost {
    public CoolGhost() {
    }

    @SpirePatch(
            clz = Hexaghost.class,
            method = SpirePatch.CONSTRUCTOR,
            paramtypez = {}
    )
    public static class BossPatch {
        public BossPatch() {
        }
        public static Texture loadTexture(String texturePath) {
            Texture texture = new Texture(texturePath);
            texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
            return texture;
        }

        @SpirePostfixPatch
        public static SpireReturn<Void> Insert(Hexaghost CoolGhost) {
            if (1==1) {
                ReflectionHacks.setPrivate(CoolGhost, AbstractCreature.class, "atlas", null);
                ReflectionHacks.setPrivate(CoolGhost, AbstractMonster.class, "img", loadTexture("redraw/images/lantern2.png"));


                //cultist.state.setAnimation(0, "Idle", true);
            }

            return SpireReturn.Continue();
        }
    }
}
