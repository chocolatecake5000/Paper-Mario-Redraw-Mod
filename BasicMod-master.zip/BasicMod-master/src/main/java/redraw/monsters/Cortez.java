package redraw.monsters;

import basemod.ReflectionHacks;
import com.badlogic.gdx.graphics.Texture;
import com.evacipated.cardcrawl.modthespire.lib.SpirePatch;
import com.evacipated.cardcrawl.modthespire.lib.SpirePostfixPatch;
import com.evacipated.cardcrawl.modthespire.lib.SpireReturn;
import com.megacrit.cardcrawl.core.AbstractCreature;
import com.megacrit.cardcrawl.monsters.AbstractMonster;
import com.megacrit.cardcrawl.monsters.beyond.Exploder;
import com.megacrit.cardcrawl.monsters.beyond.Reptomancer;
import com.megacrit.cardcrawl.monsters.beyond.Repulsor;
import com.megacrit.cardcrawl.monsters.exordium.FungiBeast;
import redraw.util.TextureLoader;


public class Cortez {
    public Cortez() {
    }

    @SpirePatch(
            clz = Reptomancer.class,
            method = SpirePatch.CONSTRUCTOR,
            paramtypez = {}
    )
    public static class BossPatch {
        public BossPatch() {
        }
        public static Texture loadTexture(String texturePath) {
            Texture texture = new Texture(texturePath);
            texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
            return texture;
        }

        @SpirePostfixPatch
        public static SpireReturn<Void> Insert(Reptomancer Cortez) {
            if (1==1) {
                ReflectionHacks.setPrivate(Cortez, AbstractCreature.class, "atlas", null);
                ReflectionHacks.setPrivate(Cortez, AbstractMonster.class, "img", loadTexture("redraw/images/Cortez.png"));


                //cultist.state.setAnimation(0, "Idle", true);
            }

            return SpireReturn.Continue();
        }
    }
}
