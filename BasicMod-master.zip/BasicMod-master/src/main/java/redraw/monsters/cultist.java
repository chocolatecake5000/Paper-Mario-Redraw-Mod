package redraw.monsters;

import TheGuardianChan.TheGuardianChan;
import basemod.ReflectionHacks;
import com.badlogic.gdx.graphics.Texture;
import com.evacipated.cardcrawl.modthespire.lib.SpirePatch;
import com.evacipated.cardcrawl.modthespire.lib.SpirePostfixPatch;
import com.evacipated.cardcrawl.modthespire.lib.SpireReturn;
import com.megacrit.cardcrawl.core.AbstractCreature;
import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
import com.megacrit.cardcrawl.monsters.AbstractMonster;
import com.megacrit.cardcrawl.monsters.exordium.Cultist;
import com.megacrit.cardcrawl.powers.AbstractPower;
import com.megacrit.cardcrawl.screens.CardRewardScreen;
import redraw.util.TextureLoader;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import static com.megacrit.cardcrawl.dungeons.AbstractDungeon.screen;


public class cultist {
    public cultist() {
    }

    @SpirePatch(
            clz = Cultist.class,
            method = SpirePatch.CONSTRUCTOR,
            paramtypez = {float.class, float.class, boolean.class}
    )
    public static class BossPatch {
        public BossPatch() {
        }
        public static Texture loadTexture(String texturePath) {
            Texture texture = new Texture(texturePath);
            texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
            return texture;
        }

        @SpirePostfixPatch
        public static SpireReturn<Void> Insert(Cultist cultist, float x, float y, boolean talk) {
            if (1==1) {
                ReflectionHacks.setPrivate(cultist, AbstractCreature.class, "atlas", null);
                ReflectionHacks.setPrivate(cultist, AbstractMonster.class, "img", loadTexture("redraw/images/CultistSmol2.png"));


                //cultist.state.setAnimation(0, "Idle", true);
            }

            return SpireReturn.Continue();
        }
    }
}
