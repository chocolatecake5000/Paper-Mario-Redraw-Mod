package redraw.monsters;

import basemod.ReflectionHacks;
import com.badlogic.gdx.graphics.Texture;
import com.evacipated.cardcrawl.modthespire.lib.SpirePatch;
import com.evacipated.cardcrawl.modthespire.lib.SpirePostfixPatch;
import com.evacipated.cardcrawl.modthespire.lib.SpireReturn;
import com.megacrit.cardcrawl.core.AbstractCreature;
import com.megacrit.cardcrawl.monsters.AbstractMonster;
import com.megacrit.cardcrawl.monsters.beyond.*;
import com.megacrit.cardcrawl.monsters.exordium.FungiBeast;
import redraw.util.TextureLoader;


public class TimeGuy {
    public TimeGuy() {
    }

    @SpirePatch(
            clz = TimeEater.class,
            method = SpirePatch.CONSTRUCTOR,
            paramtypez = {}
    )
    public static class BossPatch {
        public BossPatch() {
        }
        public static Texture loadTexture(String texturePath) {
            Texture texture = new Texture(texturePath);
            texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
            return texture;
        }

        @SpirePostfixPatch
        public static SpireReturn<Void> Insert(TimeEater TimeGuy) {
            if (1==1) {
                ReflectionHacks.setPrivate(TimeGuy, AbstractCreature.class, "atlas", null);
                ReflectionHacks.setPrivate(TimeGuy, AbstractMonster.class, "img", loadTexture("redraw/images/Kent.png"));


                //cultist.state.setAnimation(0, "Idle", true);
            }

            return SpireReturn.Continue();
        }
    }
}
