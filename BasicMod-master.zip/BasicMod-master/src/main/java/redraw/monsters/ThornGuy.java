package redraw.monsters;

import basemod.ReflectionHacks;
import com.badlogic.gdx.graphics.Texture;
import com.evacipated.cardcrawl.modthespire.lib.SpirePatch;
import com.evacipated.cardcrawl.modthespire.lib.SpirePostfixPatch;
import com.evacipated.cardcrawl.modthespire.lib.SpireReturn;
import com.megacrit.cardcrawl.core.AbstractCreature;
import com.megacrit.cardcrawl.monsters.AbstractMonster;
import com.megacrit.cardcrawl.monsters.beyond.Exploder;
import com.megacrit.cardcrawl.monsters.beyond.Spiker;
import com.megacrit.cardcrawl.monsters.exordium.FungiBeast;
import redraw.util.TextureLoader;


public class ThornGuy {
    public ThornGuy() {
    }

    @SpirePatch(
            clz = Spiker.class,
            method = SpirePatch.CONSTRUCTOR,
            paramtypez = {float.class, float.class}
    )
    public static class BossPatch {
        public BossPatch() {
        }
        public static Texture loadTexture(String texturePath) {
            Texture texture = new Texture(texturePath);
            texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
            return texture;
        }

        @SpirePostfixPatch
        public static SpireReturn<Void> Insert(Spiker ThornGuy, float x, float y) {
            if (1==1) {
                ReflectionHacks.setPrivate(ThornGuy, AbstractCreature.class, "atlas", null);
                ReflectionHacks.setPrivate(ThornGuy, AbstractMonster.class, "img", loadTexture("redraw/images/spikefriend.png"));


                //cultist.state.setAnimation(0, "Idle", true);
            }

            return SpireReturn.Continue();
        }
    }
}
