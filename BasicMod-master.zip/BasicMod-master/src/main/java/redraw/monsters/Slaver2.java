package redraw.monsters;

import basemod.ReflectionHacks;
import com.badlogic.gdx.graphics.Texture;
import com.evacipated.cardcrawl.modthespire.lib.SpirePatch;
import com.evacipated.cardcrawl.modthespire.lib.SpirePostfixPatch;
import com.evacipated.cardcrawl.modthespire.lib.SpireReturn;
import com.megacrit.cardcrawl.core.AbstractCreature;
import com.megacrit.cardcrawl.monsters.AbstractMonster;
import com.megacrit.cardcrawl.monsters.exordium.FungiBeast;
import com.megacrit.cardcrawl.monsters.exordium.SlaverBlue;
import com.megacrit.cardcrawl.monsters.exordium.SlaverRed;
import redraw.util.TextureLoader;


public class Slaver2 {
    public Slaver2() {
    }

    @SpirePatch(
            clz = SlaverRed.class,
            method = SpirePatch.CONSTRUCTOR,
            paramtypez = {float.class, float.class}
    )
    public static class BossPatch {
        public BossPatch() {
        }
        public static Texture loadTexture(String texturePath) {
            Texture texture = new Texture(texturePath);
            texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
            return texture;
        }

        @SpirePostfixPatch
        public static SpireReturn<Void> Insert(SlaverRed Slaver2, float x, float y) {
            if (1==1) {
                ReflectionHacks.setPrivate(Slaver2, AbstractCreature.class, "atlas", null);
                ReflectionHacks.setPrivate(Slaver2, AbstractMonster.class, "img", loadTexture("redraw/images/redslaver.png"));


                //cultist.state.setAnimation(0, "Idle", true);
            }

            return SpireReturn.Continue();
        }
    }
}
