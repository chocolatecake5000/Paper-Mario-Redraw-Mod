package redraw.monsters;

import basemod.ReflectionHacks;
import com.badlogic.gdx.graphics.Texture;
import com.evacipated.cardcrawl.modthespire.lib.SpirePatch;
import com.evacipated.cardcrawl.modthespire.lib.SpirePostfixPatch;
import com.evacipated.cardcrawl.modthespire.lib.SpireReturn;
import com.megacrit.cardcrawl.core.AbstractCreature;
import com.megacrit.cardcrawl.monsters.AbstractMonster;
import com.megacrit.cardcrawl.monsters.exordium.AcidSlime_M;
import com.megacrit.cardcrawl.monsters.exordium.FungiBeast;
import redraw.util.TextureLoader;


public class SlimeMed {
    public SlimeMed() {
    }

    @SpirePatch(
            clz = AcidSlime_M.class,
            method = SpirePatch.CONSTRUCTOR,
            paramtypez = {float.class, float.class, int.class,int.class}
    )
    public static class BossPatch {
        public BossPatch() {
        }
        public static Texture loadTexture(String texturePath) {
            Texture texture = new Texture(texturePath);
            texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
            return texture;
        }

        @SpirePostfixPatch
        public static SpireReturn<Void> Insert(AcidSlime_M SlimeMed, float x, float y,int poisonAmount, int newHealth) {
            if (1==1) {
                ReflectionHacks.setPrivate(SlimeMed, AbstractCreature.class, "atlas", null);
                ReflectionHacks.setPrivate(SlimeMed, AbstractMonster.class, "img", loadTexture("redraw/images/FuzzyMed.png"));


                //cultist.state.setAnimation(0, "Idle", true);
            }

            return SpireReturn.Continue();
        }
    }
}
