package redraw.util;


import basemod.ReflectionHacks;
import com.badlogic.gdx.graphics.Color;
import com.evacipated.cardcrawl.modthespire.lib.*;
import com.evacipated.cardcrawl.modthespire.patcher.PatchingException;
import com.megacrit.cardcrawl.cards.AbstractCard;
import com.megacrit.cardcrawl.characters.AbstractPlayer;
import com.megacrit.cardcrawl.cutscenes.Cutscene;
import com.megacrit.cardcrawl.cutscenes.CutscenePanel;
import com.megacrit.cardcrawl.dungeons.AbstractDungeon;
import com.megacrit.cardcrawl.helpers.ImageMaster;
import javassist.CannotCompileException;
import javassist.CtBehavior;

import java.util.ArrayList;

// replaces ironclad victory cutscene
public class RedrawHeartScenes {

    @SpirePatch2(clz = Cutscene.class, method = "<ctor>")
    public static class patch {

        @SpirePrefixPatch
        public static SpireReturn<Void> patch(Cutscene __instance, AbstractPlayer.PlayerClass chosenClass) {
            System.out.println("CutscenePatch was here");
            if (chosenClass == AbstractPlayer.PlayerClass.IRONCLAD) {
                ArrayList<CutscenePanel> panels = new ArrayList();

                panels.add(new CutscenePanel(("redraw/images/MarioHeart1.png")));
                panels.add(new CutscenePanel(("redraw/images/MarioHeart2.png"), "ATTACK_HEAVY"));
                panels.add(new CutscenePanel(("redraw/images/MarioHeart3.png")));
                ReflectionHacks.privateMethod(ImageMaster.class,  "loadImage", String.class).invoke(__instance, "images/scenes/redBg.jpg");
                ReflectionHacks.setPrivate(__instance, Cutscene.class, "panels", panels);
                ReflectionHacks.setPrivate(__instance, Cutscene.class, "bgColor", Color.WHITE.cpy());
                ReflectionHacks.setPrivate(__instance, Cutscene.class, "screenColor", new Color(0.0F, 0.0F, 0.0F, 0.0F));

            }
            else if (chosenClass == AbstractPlayer.PlayerClass.THE_SILENT) {
                ArrayList<CutscenePanel> panels = new ArrayList();

                panels.add(new CutscenePanel(("redraw/images/green1.png")));
                panels.add(new CutscenePanel(("redraw/images/green2.png"), "GOLD_JINGLE"));
                panels.add(new CutscenePanel(("redraw/images/green3.png"), "SHOP_PURCHASE"));
                ReflectionHacks.privateMethod(ImageMaster.class,  "loadImage", String.class).invoke(__instance, "images/scenes/redBg.jpg");
                ReflectionHacks.setPrivate(__instance, Cutscene.class, "panels", panels);
                ReflectionHacks.setPrivate(__instance, Cutscene.class, "bgColor", Color.WHITE.cpy());
                ReflectionHacks.setPrivate(__instance, Cutscene.class, "screenColor", new Color(0.0F, 0.0F, 0.0F, 0.0F));

            }
            else if (chosenClass == AbstractPlayer.PlayerClass.DEFECT) {
                ArrayList<CutscenePanel> panels = new ArrayList();

                panels.add(new CutscenePanel(("redraw/images/Grodius1.png")));
                panels.add(new CutscenePanel(("redraw/images/Grodius2.png"), "ORB_LIGHTNING_EVOKE"));
                panels.add(new CutscenePanel(("redraw/images/Grodius3.png")));
                ReflectionHacks.privateMethod(ImageMaster.class,  "loadImage", String.class).invoke(__instance, "images/scenes/redBg.jpg");
                ReflectionHacks.setPrivate(__instance, Cutscene.class, "panels", panels);
                ReflectionHacks.setPrivate(__instance, Cutscene.class, "bgColor", Color.WHITE.cpy());
                ReflectionHacks.setPrivate(__instance, Cutscene.class, "screenColor", new Color(0.0F, 0.0F, 0.0F, 0.0F));

            }
            else if (chosenClass == AbstractPlayer.PlayerClass.WATCHER) {
                ArrayList<CutscenePanel> panels = new ArrayList();

                panels.add(new CutscenePanel(("redraw/images/Master1.png")));
                panels.add(new CutscenePanel(("redraw/images/Master2.png"), "STANCE_ENTER_DIVINITY"));
                panels.add(new CutscenePanel(("redraw/images/master3.png")));
                ReflectionHacks.privateMethod(ImageMaster.class,  "loadImage", String.class).invoke(__instance, "images/scenes/redBg.jpg");
                ReflectionHacks.setPrivate(__instance, Cutscene.class, "panels", panels);
                ReflectionHacks.setPrivate(__instance, Cutscene.class, "bgColor", Color.WHITE.cpy());
                ReflectionHacks.setPrivate(__instance, Cutscene.class, "screenColor", new Color(0.0F, 0.0F, 0.0F, 0.0F));

            }
            return SpireReturn.Return();
        }

    }

}