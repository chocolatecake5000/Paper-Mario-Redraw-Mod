package redraw.util;

import com.evacipated.cardcrawl.modthespire.lib.SpirePatch;
import com.megacrit.cardcrawl.helpers.ImageMaster;
import com.megacrit.cardcrawl.screens.charSelect.CharacterOption;
import com.megacrit.cardcrawl.screens.charSelect.CharacterSelectScreen;
import javassist.CannotCompileException;
import javassist.expr.ExprEditor;
import javassist.expr.NewExpr;

public class CharacterSelectScreenPatch {

 //   public static String getPath(String append) {
    //    String tmp = "redraw/images/";

       // return tmp + append + ".png";
   // }

    //private static boolean firstRun2 = true;
//@SpirePatch(
       // clz = CharacterSelectScreen.class,
       // method = "initialize"
//)
//public static class ChangeBG {
   // public ChangeBG() {
   // }

  //  public static ExprEditor Instrument() {
     //   return new ExprEditor() {
         //   public void edit(NewExpr m) throws CannotCompileException {
              //  if (m.getClassName().equals(CharacterOption.class.getName()) && firstRun2) {
                  //  firstRun2 = false;
                   // m.replace("{$_ = $proceed($1, $2, " + ImageMaster.class.getName() + ".loadImage(" + CharacterSelectScreenPatch.class.getName() + ".getPath(\"MarioButtonReal\"))," + ImageMaster.class.getName() + ".loadImage(" + CharacterSelectScreenPatch.class.getName() + ".getPath(\"CHAR_SELECT_IRONCLAD\")));}");
             //   }

         //   }
      //  };
   // }
//}

}
