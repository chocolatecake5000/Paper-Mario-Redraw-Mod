//package redraw.util;

import basemod.ReflectionHacks;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.evacipated.cardcrawl.modthespire.lib.SpirePatch;
import com.evacipated.cardcrawl.modthespire.lib.SpirePostfixPatch;
import com.evacipated.cardcrawl.modthespire.lib.SpireReturn;
import com.megacrit.cardcrawl.core.AbstractCreature;
import com.megacrit.cardcrawl.monsters.AbstractMonster;
import com.megacrit.cardcrawl.monsters.beyond.AwakenedOne;

//public class HealthBarUpdate {
  //  public HealthBarUpdate() {
  //  }

   // @SpirePatch(
   //         clz = AbstractCreature.class,
   //         method = SpirePatch.CONSTRUCTOR,
   //         paramtypez = {float.class, float.class}
   // )
 //   private void renderRedHealthBar(SpriteBatch sb, float x, float y) {
    //    if (this.currentBlock > 0) {
      //      sb.setColor(this.blueHbBarColor);
      //  } else {
      //      sb.setColor(this.a57f00);
      //  }


    //}
//}