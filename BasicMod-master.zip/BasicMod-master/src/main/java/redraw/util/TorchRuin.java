package redraw.util;

import com.evacipated.cardcrawl.modthespire.lib.SpirePatch2;
import com.evacipated.cardcrawl.modthespire.lib.SpirePrefixPatch;
import com.evacipated.cardcrawl.modthespire.lib.SpireReturn;
import com.megacrit.cardcrawl.cards.AbstractCard;
import com.megacrit.cardcrawl.cutscenes.Cutscene;
import com.megacrit.cardcrawl.scenes.TheBottomScene;
import javafx.scene.Scene;

import javax.sound.midi.Patch;


public class TorchRuin {

        //@SpirePrefixPatch TheBottomScene.randomizeTorch return SpireReturn.Return();//

}
